
// frontend page code (e.g., PredictionsPage.js)
import { downloadFile } from 'backend/downloadModule';

const predictions = [
  {
    team: "Buffalo Bills",
    homeGames: ["Baltimore Ravens", "Cincinnati Bengals", "Kansas City Chiefs"],
    awayGames: ["Atlanta Falcons", "Carolina Panthers", "Pittsburgh Steelers"],
    predictedWinner: "Buffalo Bills",
    record: "12-5"
  },
  {
    team: "Chicago Bears",
    homeGames: ["Detroit Lions", "Green Bay Packers", "San Francisco 49ers"],
    awayGames: ["Arizona Cardinals", "New Orleans Saints", "Seattle Seahawks"],
    predictedWinner: "Green Bay Packers",
    record: "11-6"
  }
];

$w.onReady(function () {
  $w('#repeater1').data = predictions;

  $w('#btnDownloadTxt').onClick(() => {
    downloadFile(predictions, 'txt').then(url => {
      wixLocation.to(url);
    });
  });

  $w('#btnDownloadCsv').onClick(() => {
    downloadFile(predictions, 'csv').then(url => {
      wixLocation.to(url);
    });
  });

  $w('#btnDownloadPdf').onClick(() => {
    downloadFile(predictions, 'pdf').then(url => {
      wixLocation.to(url);
    });
  });
});
